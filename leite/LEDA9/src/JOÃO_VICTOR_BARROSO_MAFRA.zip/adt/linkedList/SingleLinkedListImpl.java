package adt.linkedList;

public class SingleLinkedListImpl<T> implements LinkedList<T> {

	protected SingleLinkedListNode<T> head;
	
	public SingleLinkedListImpl() {
		this.head = new SingleLinkedListNode<T>();
	}
	
	@Override
	public boolean isEmpty() {
		return getHead().isNIL();
	}

	@Override
	public int size() {
		int size = 0;
		SingleLinkedListNode<T> auxNode = head;
		while (! auxNode.isNIL()){
			size++;
			auxNode = auxNode.getNext();
		}
		
		return size;
	}

	@Override
	public T search(T element) {
		if (element != null) {
			SingleLinkedListNode<T> auxNode = head;
			while (! auxNode.isNIL()){
				if (auxNode.getData().equals(element)){
					return element;
				}
				auxNode = auxNode.getNext();
			}
		}
		
		return null;
	}

	@Override
	public void insert(T element) {
		if (element != null){
			
			SingleLinkedListNode<T> auxNode = head;
			while (! auxNode.isNIL()){
				auxNode = auxNode.getNext();
			}
			auxNode.data = element;
			auxNode.next = new SingleLinkedListNode<T>();		
		}

	}

	@Override
	public void remove(T element) {
		if (isEmpty()){
			return;
		}
		
		if (element != null) {
			if (head.getData().equals(element)){
				setHead(head.getNext());
				return;
			}
			
			SingleLinkedListNode<T> auxNode = head;
			while (! auxNode.getNext().isNIL()){
				if (auxNode.getNext().getData().equals(element)){					
					auxNode.next = auxNode.getNext().getNext();
					return;
				}
				auxNode = auxNode.getNext();
			}
		}
		
	}
	
	@Override
	public T[] toArray(){
		T[] array = (T[]) new Object[size()];
		SingleLinkedListNode<T> auxNode = head;
		int i = 0;
		while (! auxNode.isNIL()){
			array[i] = auxNode.getData();
			auxNode = auxNode.getNext();
			i++;
		}
		
		return array;
	}

	public SingleLinkedListNode<T> getHead() {
		return head;
	}

	public void setHead(SingleLinkedListNode<T> head) {
		this.head = head;
	}

	
}
