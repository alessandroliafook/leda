package main;

import util.Util;

public class Main {

	public static void main(String[] args) {
		
		Integer[] vetor = Util.<Integer>makeArray(10);
		
		vetor[0] = 10;
		vetor[1] = 11;

		System.out.println(vetor[0]);
		System.out.println(vetor[1]);
		
	}

}
